﻿// popup.js

const autoToggle       = document.getElementById('autoToggle');
const displayModeBtn   = document.getElementById('displayModeBtn');
const modeText         = document.getElementById('modeText');

const sourceLangSel    = document.getElementById('sourceLang');
const targetLangSel    = document.getElementById('targetLang');
const managedModelSel  = document.getElementById('managedModel');
const balanceText      = document.getElementById('balanceText');
const topupBtn         = document.getElementById('topupBtn');
const accountEmail     = document.getElementById('accountEmail');
const accountActionBtn = document.getElementById('accountActionBtn');

const WEBSITE = 'https://shiyuai.top/';

// 每个模型的计费比率（积分 / 1K Token）
const MODEL_RATES = {
  'free-translation':  0,
  'deepseek-chat':    10,
  'qwen3-235b-a22b':  20,
  'gemini-2.5-flash': 30,
  'gpt-5-mini':       50,
  'claude-sonnet-4-6': 200,
};

// 浏览器语言 -> 目标语言 映射
function detectBrowserLang() {
  const lang = navigator.language || navigator.userLanguage || 'zh-CN';
  const map = {
    'zh': 'zh-CN', 'zh-CN': 'zh-CN', 'zh-TW': 'zh-TW', 'zh-HK': 'zh-TW',
    'ja': 'ja', 'ko': 'ko', 'fr': 'fr', 'de': 'de',
    'es': 'es', 'pt': 'pt', 'ru': 'ru', 'ar': 'ar', 'it': 'it', 'en': 'en'
  };
  return map[lang] || map[lang.split('-')[0]] || 'zh-CN';
}

// ===== 初始化：加载所有设置 =====
chrome.storage.sync.get(
  ['autoTranslateEnabled', 'displayMode', 'translationEngine', 'sourceLang', 'targetLang', 'managedModel'],
  (syncResult) => {
    updateAutoTranslateUI(syncResult.autoTranslateEnabled || false);
    updateDisplayModeUI(syncResult.displayMode || 'bilingual');

    const targetLang = syncResult.targetLang || detectBrowserLang();
    const sourceLang = syncResult.sourceLang || 'auto';
    setSelectValue(sourceLangSel, sourceLang);
    setSelectValue(targetLangSel, targetLang);
    if (!syncResult.targetLang) chrome.storage.sync.set({ targetLang, sourceLang: 'auto' });

    if (syncResult.translationEngine === 'free') {
      setSelectValue(managedModelSel, 'free-translation');
    } else {
      const targetModel = syncResult.managedModel || 'deepseek-chat';
      setSelectValue(managedModelSel, targetModel);
      // 如果存储的模型在新选项列表里找不到（旧版本遗留），自动回退到免费档并修正存储
      if (managedModelSel.value !== targetModel) {
        managedModelSel.value = 'free-translation';
        chrome.storage.sync.set({ translationEngine: 'free' });
      }
    }

    // 加载余额（先用缓存，再刷新）
    chrome.storage.local.get(['cachedCredits'], (local) => {
      if (local.cachedCredits !== undefined) updateBalanceUI(local.cachedCredits);
    });
    checkLoginState();
    loadBalance();
  }
);

// ===== 账户状态 =====
function checkLoginState() {
  chrome.storage.local.get(['authToken', 'authEmail'], (stored) => {
    if (stored.authToken && stored.authEmail) {
      accountEmail.textContent     = stored.authEmail;
      accountActionBtn.textContent = '退出';
      accountActionBtn.onclick     = doLogout;
    } else {
      accountEmail.textContent     = '未登录';
      accountActionBtn.textContent = '去登录';
      accountActionBtn.onclick     = openWebsite;
    }
  });
}

function doLogout() {
  chrome.runtime.sendMessage({ action: 'logout' }, () => {
    accountEmail.textContent     = '未登录';
    accountActionBtn.textContent = '去登录';
    accountActionBtn.onclick     = openWebsite;
    if (managedModelSel.value !== 'free-translation') {
      balanceText.textContent = '余额：未登录';
      balanceText.style.color = '#9ca3af';
    } else {
      setFreeMode();
    }
  });
}

function openWebsite() {
  chrome.tabs.create({ url: WEBSITE });
}

// ===== 充值按钮  直接跳转网站 =====
topupBtn.addEventListener('click', () => {
  chrome.storage.local.get(['authToken'], (stored) => {
    const url = stored.authToken
      ? WEBSITE + '?token=' + stored.authToken
      : WEBSITE;
    chrome.tabs.create({ url });
  });
});

// ===== 余额显示 =====
function setFreeMode() {
  balanceText.textContent = '免费通道·无需登录';
  balanceText.style.color = '#10b981';
  topupBtn.textContent = '充値升级';
}

function updateBalanceUI(credits) {
  const model = managedModelSel.value;
  if (model === 'free-translation') { setFreeMode(); return; }
  topupBtn.textContent = '充値';
  const rate = MODEL_RATES[model];
  if (credits <= 0) {
    balanceText.textContent = '余额：已用尽';
    balanceText.style.color = '#ef4444';
    return;
  }
  const wanChars = Math.round(credits * 1.2 / (rate * 10));
  balanceText.textContent = `余额：约 ${wanChars || 1} 万字`;
  balanceText.style.color = '#10b981';
}

function loadBalance() {
  if (managedModelSel.value === 'free-translation') { setFreeMode(); return; }
  topupBtn.textContent = '充値';
  balanceText.textContent = '余额：加载中';
  balanceText.style.color = '#9ca3af';
  chrome.runtime.sendMessage({ action: 'getBalance' }, (res) => {
    if (res && res.ok) {
      updateBalanceUI(res.credits);
    } else if (res && res.loggedOut) {
      balanceText.textContent = '余额：未登录';
      balanceText.style.color = '#9ca3af';
    } else {
      balanceText.textContent = '余额：获取失败';
      balanceText.style.color = '#9ca3af';
    }
  });
}

// ===== 核心模型切换 =====
managedModelSel.addEventListener('change', () => {
  const val = managedModelSel.value;
  if (val === 'free-translation') {
    chrome.storage.sync.set({ translationEngine: 'free' }, () => retranslateIfAuto());
    setFreeMode();
  } else {
    chrome.storage.sync.set({ translationEngine: 'ai', aiMode: 'managed', managedModel: val }, () => retranslateIfAuto());
    topupBtn.textContent = '充値';
    chrome.storage.local.get(['cachedCredits'], (local) => {
      if (local.cachedCredits !== undefined) updateBalanceUI(local.cachedCredits);
      else loadBalance();
    });
  }
});

// ===== 语言选择 =====
sourceLangSel.addEventListener('change', () => {
  chrome.storage.sync.set({ sourceLang: sourceLangSel.value }, () => retranslateIfAuto());
});
targetLangSel.addEventListener('change', () => {
  chrome.storage.sync.set({ targetLang: targetLangSel.value }, () => retranslateIfAuto());
});

// ===== 自动翻译开关 =====
autoToggle.addEventListener('change', () => {
  const newState = autoToggle.checked;
  chrome.storage.sync.set({ autoTranslateEnabled: newState }, () => {
    updateAutoTranslateUI(newState);
    if (newState) sendToCurrentTab({ action: 'translate' });
  });
});

// ===== 显示模式按钮 =====
displayModeBtn.addEventListener('click', () => {
  chrome.storage.sync.get(['displayMode'], (result) => {
    const newMode = (result.displayMode || 'bilingual') === 'bilingual' ? 'translationOnly' : 'bilingual';
    chrome.storage.sync.set({ displayMode: newMode }, () => {
      updateDisplayModeUI(newMode);
      sendToCurrentTab({ action: 'changeDisplayMode', mode: newMode });
    });
  });
});

// ===== 辅助 =====
function retranslateIfAuto() {
  chrome.storage.sync.get(['autoTranslateEnabled'], (result) => {
    if (result.autoTranslateEnabled) sendToCurrentTab({ action: 'translate' });
  });
}

function sendToCurrentTab(msg) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs || !tabs[0]) return;
    chrome.tabs.sendMessage(tabs[0].id, msg, () => { chrome.runtime.lastError; });
  });
}

function setSelectValue(sel, value) {
  const option = sel.querySelector(`option[value="${value}"]`);
  if (option) sel.value = value;
}

function updateAutoTranslateUI(enabled) {
  if (autoToggle) autoToggle.checked = enabled;
}

function updateDisplayModeUI(mode) {
  if (mode === 'translationOnly') {
    displayModeBtn.textContent = '切换为双语对照';
    displayModeBtn.classList.add('active');
    modeText.textContent = '当前: 译文只显';
  } else {
    displayModeBtn.textContent = '切换为译文只显';
    displayModeBtn.classList.remove('active');
    modeText.textContent = '当前: 双语对照';
  }
}
